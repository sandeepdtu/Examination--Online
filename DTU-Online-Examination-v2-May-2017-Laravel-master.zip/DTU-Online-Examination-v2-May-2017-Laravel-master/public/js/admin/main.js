$(document).ready(function(e) {

	var $input = $('#refresh');

	$input.val() == 'yes' ? location.reload(true) : $input.val('yes');
});

$(function() {

	$('#createEditTestDateRange').daterangepicker({

		timePicker: true,
		timePickerIncrement: 15,
		locale: {

			format: 'MM/DD/YYYY h:mm A'
		}
	});
});

function confirmUploadNewTest(){

	return confirm('Do you really want to upload the test?');
}

function confirmCreateEditNewTest(){

	return confirm('Do you really want to save the test details?');
}
