var countdownTimer = setInterval('secondPassed()', 1000);

function secondPassed() {

	var hours = Math.floor(seconds/3600);
	var minutes_seconds = seconds%3600;
	var minutes = Math.floor(minutes_seconds/60);
	var remaining_seconds = seconds%60;

	if (remaining_seconds < 10) {
		remaining_seconds = "0" + remaining_seconds;
	}
	document.getElementById('countdown').innerHTML = hours + ":" + minutes + ":" + remaining_seconds;
	if (seconds == 0) {
		clearInterval(countdownTimer);
		alert('Time is over. Click ok to submit the test');
		document.finishLogout.submit();
	} else {
		seconds--;
	}
}
