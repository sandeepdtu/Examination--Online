$(document).ready(function(e) {

	var $input = $('#refresh');

	$input.val() == 'yes' ? location.reload(true) : $input.val('yes');

});

$(function() {

	$('input[name="dateOfBirth"]').daterangepicker({

		singleDatePicker: true,
		showDropdowns: true
	});
});

function confirmStartTest(){

	return confirm('Do you really want to start the test?');
}

function confirmTestSubmit(){

	return confirm('Do you really want to submit the test? No changes will be allowed after submission.');
}

function resetQuestionAnswer(question){

	var answers = document.getElementsByName(question);

	for(var i=0;i<answers.length;i++){

		answers[i].checked = false;
	}
}

function upadteTestAnswers(question, value){

	$.ajax({

		url: '/student/patchTestAnswer',
		headers: {

			'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
			'Content-Type':'application/x-www-form-urlencoded'
		},
		method: 'PATCH',
		dataType: 'html',
		data: {

			timeDuration: seconds,
			question: question,
			value: value
		}
	  });
}

window.onbeforeunload = function(event) {

	if(seconds != null){

		upadteTestAnswers('NULL','NULL');
	}
	return null;
};
