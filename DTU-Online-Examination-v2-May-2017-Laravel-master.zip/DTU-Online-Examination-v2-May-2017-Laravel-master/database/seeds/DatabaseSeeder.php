<?php

use Illuminate\Database\Seeder;
use App\Models\Administrator;
use App\Models\User;
use App\Models\TestDetail;

class DatabaseSeeder extends Seeder
{
	/**
	 * Run the database seeds.
	 *
	 * @return void
	 */
	public function run()
	{

		$this->call(UsersTableSeeder::class);
		$this->call(AdministratorsTableSeeder::class);
		$this->call(TestDetailsTableSeeder::class);
	}
}

class UsersTableSeeder extends Seeder{

	public function run(){

		$User = new User;
		$User->registerationNumber = '12345678';
		$User->department = 'CSE';
		$User->name = 'sandeep';
		$User->dateOfBirth = '26-07-1985';
		$User->profilePictureLink = '';
		$User->save();

		$User = new User;
		$User->registerationNumber = '12345679';
		$User->department = 'CSE';
		$User->name = 'sandeep Choudhary';
		$User->dateOfBirth = '23-04-1999';
		$User->save();

		$User = new User;
		$User->registerationNumber = '12345677';
		$User->department = 'AP';
		$User->name = 'Hello';
		$User->dateOfBirth = '30-04-1999';
		$User->save();

		$User = new User;
		$User->registerationNumber = '12345676';
		$User->department = 'CSE-IT';
		$User->name = 'Hello';
		$User->dateOfBirth = '03-09-1999';
		$User->save();
	}
}

class AdministratorsTableSeeder extends Seeder{

	public function run(){

		$Administrator = new Administrator;
		$Administrator->username = 'AC';
		$Administrator->department = 'Applied Chemistry';
		$Administrator->password = md5('r00t@21o3');
		$Administrator->save();

		$Administrator = new Administrator;
		$Administrator->username = 'AP';
		$Administrator->department = 'Applied Physics';
		$Administrator->password = md5('r00t@21o3');
		$Administrator->save();

		$Administrator = new Administrator;
		$Administrator->username = 'AM';
		$Administrator->department = 'Applied Mathematics';
		$Administrator->password = md5('r00t@21o3');
		$Administrator->save();

		$Administrator = new Administrator;
		$Administrator->username = 'BT';
		$Administrator->department = 'Biotechnology';
		$Administrator->password = md5('r00t@21o3');
		$Administrator->save();

		$Administrator = new Administrator;
		$Administrator->username = 'CE';
		$Administrator->department = 'Civil Engineering';
		$Administrator->password = md5('r00t@21o3');
		$Administrator->save();

		$Administrator = new Administrator;
		$Administrator->username = 'CSE';
		$Administrator->department = 'Computer Science Engineering';
		$Administrator->password = md5('r00t@21o3');
		$Administrator->save();

		$Administrator = new Administrator;
		$Administrator->username = 'EE';
		$Administrator->department = 'Electrical Engineering';
		$Administrator->password = md5('r00t@21o3');
		$Administrator->save();

		$Administrator = new Administrator;
		$Administrator->username = 'ECE';
		$Administrator->department = 'Electronics & Communication Engineering';
		$Administrator->password = md5('r00t@21o3');
		$Administrator->save();

		$Administrator = new Administrator;
		$Administrator->username = 'ENE';
		$Administrator->department = 'Enivironmental Engineering';
		$Administrator->password = md5('r00t@21o3');
		$Administrator->save();

		$Administrator = new Administrator;
		$Administrator->username = 'HUM';
		$Administrator->department = 'Humanities';
		$Administrator->password = md5('r00t@21o3');
		$Administrator->save();

		$Administrator = new Administrator;
		$Administrator->username = 'IT';
		$Administrator->department = 'Information Technology';
		$Administrator->password = md5('r00t@21o3');
		$Administrator->save();

		$Administrator = new Administrator;
		$Administrator->username = 'ME';
		$Administrator->department = 'Mechanical Engineering';
		$Administrator->password = md5('r00t@21o3');
		$Administrator->save();

		$Administrator = new Administrator;
		$Administrator->username = 'MG';
		$Administrator->department = 'Management';
		$Administrator->password = md5('r00t@21o3');
		$Administrator->save();

		$Administrator = new Administrator;
		$Administrator->username = 'CSE-IT';
		$Administrator->department = 'Computer Science Engineering & Information Technology';
		$Administrator->password = md5('r00t@21o3');
		$Administrator->save();
	}
}

class TestDetailsTableSeeder extends Seeder{

	public function run(){

		$TestDetail = new TestDetail;
		$TestDetail->department = 'AC';
		$TestDetail->save();

		$TestDetail = new TestDetail;
		$TestDetail->department = 'AP';
		$TestDetail->save();

		$TestDetail = new TestDetail;
		$TestDetail->department = 'AM';
		$TestDetail->save();

		$TestDetail = new TestDetail;
		$TestDetail->department = 'BT';
		$TestDetail->save();

		$TestDetail = new TestDetail;
		$TestDetail->department = 'CE';
		$TestDetail->save();

		$TestDetail = new TestDetail;
		$TestDetail->department = 'CSE';
		$TestDetail->save();

		$TestDetail = new TestDetail;
		$TestDetail->department = 'EE';
		$TestDetail->save();

		$TestDetail = new TestDetail;
		$TestDetail->department = 'ECE';
		$TestDetail->save();

		$TestDetail = new TestDetail;
		$TestDetail->department = 'ENE';
		$TestDetail->save();

		$TestDetail = new TestDetail;
		$TestDetail->department = 'ME';
		$TestDetail->save();

		$TestDetail = new TestDetail;
		$TestDetail->department = 'MG';
		$TestDetail->save();

		$TestDetail = new TestDetail;
		$TestDetail->department = 'CSE-IT';
		$TestDetail->save();
		
		$TestDetail = new TestDetail;
                $TestDetail->department = 'IT';
                $TestDetail->save();
                
                $TestDetail = new TestDetail;
                $TestDetail->department = 'HUM';
                $TestDetail->save();

	}
}
