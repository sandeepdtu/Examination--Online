<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTestAnswersTable extends Migration
{
	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('test_answers', function (Blueprint $table) {
			$table->increments('id');
			$table->integer('student_id');
			$table->string('department');
			$table->string('timeDuration');

			for ($i=1; $i <= env('MAX_QUESTIONS_COUNT'); $i++) {

				$table->string('q' . $i)->nullable();
			}

			$table->boolean('finished')->default(0);
			$table->timestamps();
		});
	}

	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::dropIfExists('test_answers');
	}
}
