<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateUsersTable extends Migration
{
	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('users', function (Blueprint $table) {
			$table->increments('id');
			$table->string('registerationNumber')->unique();
			$table->string('department');
			$table->string('name');
			$table->string('dateOfBirth');
			$table->string('profilePictureLink')->nullable();
			$table->boolean('loginCheck')->default(0);
			$table->string('spec1')->nullable();
			$table->string('spec2')->nullable();
			$table->string('spec3')->nullable();
			$table->string('spec4')->nullable();
			$table->boolean('pd')->default(0);
			$table->string('category')->nullable();
			$table->string('type')->nullable();
			$table->timestamps();
		});
	}

	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::dropIfExists('users');
	}
}
