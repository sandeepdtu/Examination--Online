<?php

namespace App;

class Common{

	public static function getNumberOfQuestions($departmentUsername){

		$filePath = base_path() . '/public/tests/' . $departmentUsername . '/';

		$numberOfQuestions = 0;

		foreach (glob($filePath.'*.*') as $file) {

			$explodedFile = explode('/',$file);
			$explodedFile = explode('.', $explodedFile[sizeof($explodedFile)-1]);
			if($explodedFile[1] == 'pdf'){

				$numberOfQuestions = $explodedFile[0];
				break;
			}
		}

		return $numberOfQuestions;
	}
}
