<?php

namespace App\Http\Middleware\Admin;

use Redirect;
use Closure;

class LoginCheckTrue
{
	public function handle($request, Closure $next)
	{
		$loginStatusAdmin = $request->session()->get('loginStatusAdmin');

		if(isset($loginStatusAdmin) && $loginStatusAdmin == 'true'){

			return Redirect::to('/admin/dashboard');
		}

		return $next($request);
	}
}
