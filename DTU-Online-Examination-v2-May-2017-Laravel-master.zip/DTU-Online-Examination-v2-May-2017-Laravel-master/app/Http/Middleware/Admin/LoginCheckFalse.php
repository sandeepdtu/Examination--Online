<?php

namespace App\Http\Middleware\Admin;

use Redirect;
use Closure;

class LoginCheckFalse
{
	public function handle($request, Closure $next)
	{
		$loginStatusAdmin = $request->session()->get('loginStatusAdmin');

		if(!isset($loginStatusAdmin) || (isset($loginStatusAdmin) && $loginStatusAdmin == 'false')){

			return Redirect::to('/admin');
		}

		return $next($request);
	}
}
