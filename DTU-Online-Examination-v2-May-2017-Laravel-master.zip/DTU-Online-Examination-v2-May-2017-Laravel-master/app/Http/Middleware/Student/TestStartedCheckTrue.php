<?php

namespace App\Http\Middleware\Student;

use Redirect;
use Closure;

class TestStartedCheckTrue
{
	public function handle($request, Closure $next)
	{
		$testStarted = $request->session()->get('testStarted');

		if(isset($testStarted) && $testStarted == 'true'){

			return Redirect::to('/student/test');
		}

		return $next($request);
	}
}
