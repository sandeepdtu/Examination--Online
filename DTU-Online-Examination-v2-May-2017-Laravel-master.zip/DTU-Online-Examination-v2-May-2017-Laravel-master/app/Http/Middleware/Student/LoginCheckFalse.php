<?php

namespace App\Http\Middleware\Student;

use Redirect;
use Closure;

class LoginCheckFalse
{
	public function handle($request, Closure $next)
	{
		$loginStatusStudent = $request->session()->get('loginStatusStudent');

		if(!isset($loginStatusStudent) || (isset($loginStatusStudent) && $loginStatusStudent == 'false')){

			return Redirect::to('/student');
		}

		return $next($request);
	}
}
