<?php

namespace App\Http\Middleware\Student;

use Redirect;
use Closure;

class TestStartedCheckFalse
{
	public function handle($request, Closure $next)
	{
		$testStarted = $request->session()->get('testStarted');

		if(!isset($testStarted) || (isset($testStarted) && $testStarted == 'false')){

			return Redirect::to('/student/dashboard');
		}

		return $next($request);
	}
}
