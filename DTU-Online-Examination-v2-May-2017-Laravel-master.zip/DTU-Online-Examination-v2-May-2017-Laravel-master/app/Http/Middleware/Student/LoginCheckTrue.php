<?php

namespace App\Http\Middleware\Student;

use Redirect;
use Closure;

class LoginCheckTrue
{
	public function handle($request, Closure $next)
	{
		$loginStatusStudent = $request->session()->get('loginStatusStudent');

		if(isset($loginStatusStudent) && $loginStatusStudent == 'true'){

			return Redirect::to('/student/dashboard');
		}

		return $next($request);
	}
}
