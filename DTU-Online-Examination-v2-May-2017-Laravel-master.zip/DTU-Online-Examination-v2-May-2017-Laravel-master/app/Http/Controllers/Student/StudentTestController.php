<?php

namespace App\Http\Controllers\Student;

use Redirect;
use Illuminate\Http\Request;

use App\Common;
use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\TestAnswer;
use App\Models\TestDetail;
use \Carbon\Carbon;

class StudentTestController extends Controller
{

	public function startTest(Request $request){

		try{

			$User = User::find($request->session()->get('studentId'));
			$department = $request->input('department');

			$TestAnswer = TestAnswer::where('student_id', $request->session()->get('studentId'))->where('department',$department)->where('finished',1)->first();

			if($TestAnswer){

				$User->loginCheck = 0;
				$User->save();
				$request->session()->flush();
				return Redirect::to('/student?error=testTaken');
			}

			$TestAnswer = TestAnswer::where('student_id', $request->session()->get('studentId'))->where('department',$department)->first();
			$TestDetail = TestDetail::where('department', $department)->first();

			$startTime = Carbon::parse($TestDetail->startTime);
			$endTime = Carbon::parse($TestDetail->endTime);

			if(Carbon::now()->gte($startTime) && Carbon::now()->lte($endTime)){

				$request->session()->put('department', $department);
				$request->session()->put('testStarted', 'true');

				if(!$TestAnswer){

					$TestAnswer = new TestAnswer;
					$TestAnswer->student_id = $User->id;
					$TestAnswer->department = $department;
					$TestAnswer->timeDuration = $TestDetail->testDuration;
					$TestAnswer->save();
				}

				return Redirect::to('/student/test');
			}

			$User->loginCheck = 0;
			$User->save();
			$request->session()->flush();
			return Redirect::to('/student?error=testTimingError');
		}
		catch (\Exception $e) {

			return Redirect::to('/student/dashboard?alert=error');
		}
	}

	public function showTest(Request $request){

		$department = $request->session()->get('department');
		$studentId = $request->session()->get('studentId');

		$User = User::find($studentId);

		$numberOfQuestions = Common::getNumberOfQuestions($department);
		$filePath = '/tests/' . $department . '/' . $numberOfQuestions . '.pdf';

		$TestAnswer = TestAnswer::where('student_id',$studentId)->where('department',$department)->first();

		$answers = array();

		for ($i=1; $i <= $numberOfQuestions; $i++) {

			$answers['q' . $i] = array(

				'a' => ($TestAnswer->{'q' . $i} && $TestAnswer->{'q' . $i} == 'a') ? 1 : 0,
				'b' => ($TestAnswer->{'q' . $i} && $TestAnswer->{'q' . $i} == 'b') ? 1 : 0,
				'c' => ($TestAnswer->{'q' . $i} && $TestAnswer->{'q' . $i} == 'c') ? 1 : 0,
				'd' => ($TestAnswer->{'q' . $i} && $TestAnswer->{'q' . $i} == 'd') ? 1 : 0
			);
		}

		$profilePictureLink = '/img/defaultProfilePicture.png';

		if($User->profilePictureLink){

			$profilePictureLink = $User->profilePictureLink;
		}

		return view('student.test', [

			'title' => 'Test',
			'filePath' => $filePath,
			'timeDuration' => $TestAnswer->timeDuration,
			'answers' => $answers,
			'numberOfQuestions' => $numberOfQuestions,
			'name' => $User->name,
			'registerationNumber' => $User->registerationNumber,
			'department' => $User->department,
			'profilePictureLink' => $profilePictureLink
		]);
	}

	public function patchTestAnswer(Request $request){

		$timeDuration = $request->input('timeDuration');
		$question = $request->input('question');
		$value = $request->input('value');

		if($value == 'NULL'){

			$value = NULL;
		}

		$TestAnswer = TestAnswer::where('student_id',$request->session()->get('studentId'))->where('department',$request->session()->get('department'))->first();
		$TestAnswer->timeDuration = $timeDuration;
		if($question != 'NULL'){

			$TestAnswer->{$question} = $value;
		}
		$TestAnswer->save();

		return response()->json('success');
	}

	public function testSubmit(Request $request){

		$TestDetail = TestDetail::where('department',$request->session()->get('department'))->first();

		$TestAnswer = TestAnswer::where('student_id',$request->session()->get('studentId'))->where('department',$request->session()->get('department'))->first();
		$TestAnswer->finished = 1;
		$TestAnswer->save();

		$User = User::find($request->session()->get('studentId'));
		$User->loginCheck = 0;
		$User->save();
		$request->session()->flush();

		$numberOfQuestionsAttempted = 0;

		for ($i=1; $i <= env('MAX_QUESTIONS_COUNT'); $i++) {

			if($TestAnswer->{'q' . $i}){

				$numberOfQuestionsAttempted++;
			}
		}

		$timeTaken = $TestDetail->testDuration-$TestAnswer->timeDuration;

		$hoursTaken = intval($timeTaken/3600);
		$minutesTaken = intval(($timeTaken%3600)/60);
		$secondsTaken = ($timeTaken%3600)%60;

		$request->session()->put('testData',['numberOfQuestionsAttempted' => $numberOfQuestionsAttempted, 'hoursTaken' => $hoursTaken, 'minutesTaken' => $minutesTaken, 'secondsTaken' => $secondsTaken]);

		return Redirect::to('/student/testFinished');
	}

	public function showTestFinished(Request $request){

		try{

			$testData = $request->session()->get('testData');
			$request->session()->flush();

			return view('student.testFinished', array_merge(['title' => 'Test Finished'], $testData));
		}
		catch (\Exception $e) {

			return Redirect::to('/student');
		}
	}
}
