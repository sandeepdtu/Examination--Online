<?php

namespace App\Http\Controllers\Student;

use Redirect;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;

class StudentLoginController extends Controller
{
	public function redirectLogin(){

		return Redirect::to('/student/');
	}

	public function showLogin(Request $request){

		$error = $request->input('error');

		if($error){

			if($error == 'incorrectCredentials'){

				return view('student.login', ['title' => 'Student Login', 'error' => 'Incorrect Credentials']);
			}
			else if($error == 'anotherLogin'){

				return view('student.login', ['title' => 'Student Login', 'error' => 'Another Computer is Already Logged into this account']);
			}
			else if($error == 'dashboardError'){

				return view('student.login', ['title' => 'Student Login', 'error' => 'There is some issue with the test']);
			}
			else if($error == 'testTaken'){

				return view('student.login', ['title' => 'Student Login', 'error' => 'Test already taken']);
			}
			else if($error == 'testTimingError'){

				return view('student.login', ['title' => 'Student Login', 'error' => 'Test can not be started due to timing restrictions']);
			}
		}
		else{

			return view('student.login', ['title' => 'Student Login']);
		}
	}

	public function loginSubmit(Request $request){

		$registerationNumber = $request->input('registerationNumber');
		$dateOfBirth = $request->input('dateOfBirth');
		$dateOfBirth = explode('/', $dateOfBirth);

		$dateOfBirth = $dateOfBirth[1] . '-' . $dateOfBirth[0] . '-' . $dateOfBirth[2];

		$User = User::where('registerationNumber', $registerationNumber)->where('dateOfBirth', $dateOfBirth)->first();

		if($User){

			if($User->loginCheck == 1){

				return Redirect::to('/student?error=anotherLogin');
			}

			$User->loginCheck = 1;
			$User->save();

			$request->session()->put('loginStatusStudent', 'true');
			$request->session()->put('studentId', $User->id);
			return Redirect::to('/student/dashboard');
		}
		else{

			return Redirect::to('/student?error=incorrectCredentials');
		}
	}
}
