<?php

namespace App\Http\Controllers\Student;

use Redirect;
use Illuminate\Http\Request;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Common;

class StudentDashboardController extends Controller
{

	public function showDashboard(Request $request){

		try{

			$alert = $request->input('alert');
			$userId = $request->session()->get('studentId');

			$User = User::find($userId);

			$specs = array();

			for ($i=1; $i <= 4; $i++) {

				if($User->{'spec' . $i}){

					$specs[] = $User->{'spec' . $i};
				}
			}

			$department = $User->department;

			$numberOfQuestions = array();

			if(sizeof($specs) == 0){

				$numberOfQuestions[$department] = Common::getNumberOfQuestions($department);
			}
			else{

				for ($i=0; $i < sizeof($specs); $i++) {

					$numberOfQuestions[$department . '-' . $specs[$i]] = Common::getNumberOfQuestions($department . '-' . $specs[$i]);
				}
			}

			$profilePictureLink = '/img/defaultProfilePicture.png';

			if($User->profilePictureLink){

				$profilePictureLink = $User->profilePictureLink;
			}

			return view('student.dashboard',[

				'title' => 'Student Dashboard',
				'numberOfQuestions' => $numberOfQuestions,
				'alert' => $alert,
				'name' => $User->name,
				'registerationNumber' => $User->registerationNumber,
				'department' => $User->department,
				'profilePictureLink' => $profilePictureLink
			]);
		}
		catch (\Exception $e) {

			$User = User::find($request->session()->get('studentId'));
			$User->loginCheck = 0;
			$User->save();
			$request->session()->flush();
			return Redirect::to('/student?error=dashboardError');
		}
	}
}
