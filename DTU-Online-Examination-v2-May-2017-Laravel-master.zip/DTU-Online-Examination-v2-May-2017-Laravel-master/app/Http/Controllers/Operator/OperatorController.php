<?php

namespace App\Http\Controllers\Operator;

use Redirect;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\TestDetail;
use App\Models\TestAnswer;

class OperatorController extends Controller
{
	public function showInput(Request $request){

		$error = $request->input('error');

		if($error){

			if($error == 'incorrectCredentials'){

				return view('input.login', ['title' => 'Student examination details', 'error' => 'Some error has occured.']);
			}
		}
		else{

			return view('operator.input', ['title' => 'Student examination details']);
		}
	}

	public function postSubmit(Request $request){

		$registerationNumber = $request->input('registerationNumber');
		$department = $request->input('department');

		return Redirect::to('/operator/acknowledgement/' . $registerationNumber . '/' . $department);
	}

	public function showAcknowledgement(Request $request, $registerationNumber, $department){

		$User = User::where('registerationNumber', $registerationNumber)->first();

		$profilePictureLink = '/img/defaultProfilePicture.png';

		if($User->profilePictureLink){

			$profilePictureLink = $User->profilePictureLink;
		}

		$department = strtoupper($department);

		$TestAnswer = TestAnswer::where('student_id', $User->id)->where('department', $department)->where('finished', 1)->first();

		$questions = array();

		for ($i=1; $i <= env('MAX_QUESTIONS_COUNT'); $i++) {

			if($TestAnswer->{'q' . $i}){

				$questions[$i] = strtoupper($TestAnswer->{'q' . $i});
			}
		}

		$TestDetail = TestDetail::where('department',$department)->first();

		$timeTaken = $TestDetail->testDuration-$TestAnswer->timeDuration;

		$hoursTaken = intval($timeTaken/3600);
		$minutesTaken = intval(($timeTaken%3600)/60);
		$secondsTaken = ($timeTaken%3600)%60;

		return view('operator.acknowledgement', [

			'title' => 'Student acknowledgement',
			'name' => $User->name,
			'registerationNumber' => $User->registerationNumber,
			'department' => $User->department,
			'pd' => $User->pd == 1 ? 'Yes': 'No',
			'profilePictureLink' => $profilePictureLink,
			'questions' => $questions,
			'hoursTaken' => $hoursTaken,
			'minutesTaken' => $minutesTaken,
			'secondsTaken' => $secondsTaken
		]);
	}
}
