<?php

namespace App\Http\Controllers\Admin;

use Redirect;
use Illuminate\Http\Request;

use App\Http\Controllers\Controller;
use App\Models\TestAnswer;
use App\Models\TestDetail;
use App\Models\User;

class AdminResultController extends Controller
{
	protected function fileInit($fileName){

		$header = array('Registration Number','Department','Name','Spec 1','Spec 2','Spec 3','Spec 4','PD','Category','Type');

		for($i=1; $i <= env('MAX_QUESTIONS_COUNT'); $i++) {

			$header[] = 'Question ' . $i;
		}

		$header = array_merge($header, array('No. of question attempted','No. of questions correct','No. of questions incorrect','Marks'));

		$filePath = base_path() . '/public/results/';

		if (!is_dir($filePath)) {

			mkdir($filePath, 0777, true);
		}

		$fp = fopen($filePath . $fileName . '.csv', 'w');
		fputcsv($fp, $header);

		return $fp;
	}

	protected function calculateResult($TestDetail, $fp){

		$results = array();

		$TestAnswers = TestAnswer::where('department',$TestDetail->department)->where('finished', 1)->get();

		foreach ($TestAnswers as $TestAnswer) {

			$User = User::find($TestAnswer->student_id);

			$csvData = array($User->registerationNumber, $User->department, $User->name, $User->spec1, $User->spec2, $User->spec3, $User->spec4, $User->pd, $User->category, $User->type);

			$attempted = 0;
			$correct = 0;
			$incorrect = 0;
			for ($i=1; $i <= env('MAX_QUESTIONS_COUNT'); $i++) {

				$csvData = array_merge($csvData, array($TestAnswer->{'q' . $i}));

				if($TestAnswer->{'q' . $i}){

					$attempted++;

					if($TestAnswer->{'q' . $i} == $TestDetail->{'q' . $i}){

						$correct++;
					}
					else{

						$incorrect++;
					}
				}
			}

			$marks = $correct*$TestDetail->marksGained - $incorrect*$TestDetail->marksLost;

			$csvData = array_merge($csvData, array($attempted, $correct, $incorrect, $marks));
			fputcsv($fp, $csvData);

			$results[] = array(

				'registerationNumber' => $User->registerationNumber,
				'name' => $User->name,
				'attempted' => $attempted,
				'correct' => $correct,
				'incorrect' => $incorrect,
				'marks' => $marks
			);
		}

		return $results;
	}

	public function showResults(Request $request){

		try{

			$department = $request->session()->get('departmentUsername');

			$fp = self::fileInit($department);

			$TestDetail = TestDetail::where('department',$department)->first();

			$results = array(

				$department => self::calculateResult($TestDetail, $fp)
			);

			return view('admin.results',['title' => 'Results', 'results' => $results, 'type' => 0, 'file' => '/results/' . $department . '.csv']);
		}
		catch (\Exception $e) {

			return Redirect::to('/admin/dashboard?alert=error');
		}
	}

	public function showAllResults(Request $request){

		try{

			$fp = self::fileInit('All-Results');

			$TestDetails = TestDetail::all();

			$results = array();

			foreach ($TestDetails as $TestDetail) {

				$results[$TestDetail->department] = self::calculateResult($TestDetail, $fp);
			}

			return view('admin.results',['title' => 'Results', 'results' => $results, 'type' => 1, 'file' => '/results/All-Results.csv']);
		}
		catch (\Exception $e) {

			return Redirect::to('/admin/dashboard?alert=error');
		}
	}
}
