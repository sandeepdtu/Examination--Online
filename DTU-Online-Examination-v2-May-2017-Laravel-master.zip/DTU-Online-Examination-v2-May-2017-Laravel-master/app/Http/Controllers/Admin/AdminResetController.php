<?php

namespace App\Http\Controllers\Admin;

use Redirect;
use Illuminate\Http\Request;

use App\Http\Controllers\Controller;
use App\Models\User;

class AdminResetController extends Controller
{
	public function showResetStudentLogin(Request $request){

		try{

			return view('admin.reset',['title' => 'Reset']);
		}
		catch (\Exception $e) {

			return Redirect::to('/admin/dashboard?alert=error');
		}
	}

	public function resetStudentLoginSubmit(Request $request){

		try{

			$User = User::where('registerationNumber', $request->input('registerationNumber'))->first();
			$User->loginCheck = 0;
			$User->save();

			return Redirect::to('/admin/dashboard?alert=resetStudentLogin');
		}
		catch (\Exception $e) {

			return Redirect::to('/admin/dashboard?alert=error');
		}
	}
}
