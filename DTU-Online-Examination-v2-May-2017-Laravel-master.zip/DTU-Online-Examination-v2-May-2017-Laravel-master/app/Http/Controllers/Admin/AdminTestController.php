<?php

namespace App\Http\Controllers\Admin;

use Redirect;
use Illuminate\Http\Request;
use App\Common;

use App\Http\Controllers\Controller;
use App\Models\Administrator;
use App\Models\TestDetail;

class AdminTestController extends Controller
{
	protected function deleteDir($dirPath){

		if (!is_dir($dirPath)) {

			if (file_exists($dirPath) !== false) {

				unlink($dirPath);
			}
			return;
		}

		if ($dirPath[strlen($dirPath) - 1] != '/') {

			$dirPath .= '/';
		}

		$files = glob($dirPath . '*', GLOB_MARK);
		foreach ($files as $file) {

			if (is_dir($file)) {

				deleteDir($file);
			}
			else {

				unlink($file);
			}
		}

		rmdir($dirPath);
	}

	protected function retrieveValues($departmentUsername ,$numberOfQuestions, $type){

		if($type == 'view'){

			$defaultValues = array(

				'timeHours' => 'NULL',
				'timeMinutes' => 'NULL',
				'marksGained' => 'NULL',
				'marksLost' => 'NULL',
				'createEditTestDateRange' => ''
			);
		}
		else{

			$defaultValues = array(

				'timeHours' => 1,
				'timeMinutes' => 0,
				'marksGained' => 3,
				'marksLost' => 1,
				'createEditTestDateRange' => ''
			);
		}

		$returnArray = array();

		$TestDetail = TestDetail::where('department', $departmentUsername)->first();

		$testDuration = $TestDetail->testDuration;

		if($testDuration && $type != 'create'){

			$returnArray['timeHours'] = intval(intval($testDuration)/3600);
			$returnArray['timeMinutes'] =  intval((intval($testDuration)%3600)/60);
		}
		else{

			$returnArray['timeHours'] = $defaultValues['timeHours'];
			$returnArray['timeMinutes'] =  $defaultValues['timeMinutes'];
		}

		for ($i=1; $i <= $numberOfQuestions; $i++) {

			$returnArray['q' . $i] = array(

				'a' => ($TestDetail->{'q' . $i} && $TestDetail->{'q' . $i} == 'a' && $type != 'create') ? 1 : 0,
				'b' => ($TestDetail->{'q' . $i} && $TestDetail->{'q' . $i} == 'b' && $type != 'create') ? 1 : 0,
				'c' => ($TestDetail->{'q' . $i} && $TestDetail->{'q' . $i} == 'c' && $type != 'create') ? 1 : 0,
				'd' => ($TestDetail->{'q' . $i} && $TestDetail->{'q' . $i} == 'd' && $type != 'create') ? 1 : 0
			);
		}

		$returnArray['marksGained'] = ((isset($TestDetail->marksGained) || (isset($TestDetail->marksGained) && $TestDetail->marksGained == 0)) && $type != 'create') ? $TestDetail->marksGained : $defaultValues['marksGained'];
		$returnArray['marksLost'] = ((isset($TestDetail->marksLost) || (isset($TestDetail->marksLost) && $TestDetail->marksLost == 0)) && $type != 'create') ? $TestDetail->marksLost : $defaultValues['marksLost'];

		$returnArray['createEditTestDateRange'] = ($TestDetail->startTime && $TestDetail->endTime && $type != 'create') ? $TestDetail->startTime . ' - ' . $TestDetail->endTime : $defaultValues['createEditTestDateRange'];

		return $returnArray;
	}

	public function showUploadNewTest(Request $request){

		return view('admin.uploadNewTest',['title' => 'Upload a new Test', 'maxQuestionsCount' => env('MAX_QUESTIONS_COUNT')]);
	}

	public function uploadNewTestSubmit(Request $request){

		try{

			$file = $request->file('file');
			$numberOfQuestions = $request->input('numberOfQuestions');
			$departmentUsername = $request->session()->get('departmentUsername');

			if(strtolower($file->getClientOriginalExtension() == 'pdf')){

				$filePath = base_path() . '/public/tests/' . $departmentUsername . '/';

				self::deleteDir($filePath);

				mkdir($filePath, 0777, true);

				$file->move($filePath, $numberOfQuestions . '.pdf');
				return Redirect::to('/admin/dashboard?alert=fileUploaded');
			}
			else{

				return view('admin.uploadNewTest',['title' => 'Upload a new Test', 'error' => 'Invalid file extenesion']);
			}
		}
		catch (\Exception $e) {

			return Redirect::to('/admin/dashboard?alert=error');
		}
	}

	public function showCreateNewTest(Request $request){

		try{

			$departmentUsername = $request->session()->get('departmentUsername');
			$numberOfQuestions = Common::getNumberOfQuestions($departmentUsername);
			$values = self::retrieveValues($departmentUsername, $numberOfQuestions, 'create');
			return view('admin.createEditTest',[

				'title' => 'Create a new Test',
				'numberOfQuestions' => $numberOfQuestions,
				'type' => 'create',
				'values' => $values
			]);
		}
		catch (\Exception $e) {

			return Redirect::to('/admin/dashboard?alert=error');
		}
	}

	public function createEditTestSubmit(Request $request){

		try{

			$numberOfQuestions = $request->input('numberOfQuestions');
			$timeHours = $request->input('timeHours');
			$timeMinutes = $request->input('timeMinutes');
			$mgpca = $request->input('mgpca');
			$mlpia = $request->input('mlpia');
			$createEditTestDateRange = $request->input('createEditTestDateRange');

			$explodedDateRange = explode(' - ', $createEditTestDateRange);
			$startDateTime = $explodedDateRange[0];
			$endDateTime = $explodedDateRange[1];

			$department = $request->session()->get('departmentUsername');

			$TestDetail = TestDetail::where('department', $department)->first();
			$TestDetail->testDuration = $timeHours*60*60 + $timeMinutes*60;

			for($i = 1; $i <= $numberOfQuestions; $i++){

				$TestDetail->{'q' . $i} = $request->input('q' . $i);
			}

			$TestDetail->marksGained = $mgpca;
			$TestDetail->marksLost = $mlpia;
			$TestDetail->startTime = $startDateTime;
			$TestDetail->endTime = $endDateTime;
			$TestDetail->save();

			return Redirect::to('/admin/dashboard?alert=testDetails');
		}
		catch (\Exception $e) {

			return Redirect::to('/admin/dashboard?alert=error');
		}
	}

	public function showEditTest(Request $request){

		try{

			$departmentUsername = $request->session()->get('departmentUsername');
			$numberOfQuestions = Common::getNumberOfQuestions($departmentUsername);
			$values = self::retrieveValues($departmentUsername, $numberOfQuestions, 'edit');
			return view('admin.createEditTest',[

				'title' => 'Edit Test',
				'numberOfQuestions' => $numberOfQuestions,
				'type' => 'edit',
				'values' => $values
			]);
		}
		catch (\Exception $e) {

			return Redirect::to('/admin/dashboard?alert=error');
		}
	}

	public function showViewTest(Request $request){

		try{

			$departmentUsername = $request->session()->get('departmentUsername');
			$numberOfQuestions = Common::getNumberOfQuestions($departmentUsername);
			$values = self::retrieveValues($departmentUsername, $numberOfQuestions, 'view');
			return view('admin.viewTest',[

				'title' => 'View Test',
				'numberOfQuestions' => $numberOfQuestions,
				'values' => $values
			]);
		}
		catch (\Exception $e) {

			return Redirect::to('/admin/dashboard?alert=error');
		}
	}
}
