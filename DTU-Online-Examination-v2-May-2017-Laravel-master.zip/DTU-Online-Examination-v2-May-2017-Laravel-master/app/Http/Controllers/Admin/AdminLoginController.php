<?php

namespace App\Http\Controllers\Admin;

use Redirect;
use Illuminate\Http\Request;

use App\Http\Controllers\Controller;
use App\Models\Administrator;

class AdminLoginController extends Controller
{
	public function showLogin(Request $request){

		$error = $request->input('error');

		if($error){

			return view('admin.login', ['title' => 'Administrator Login', 'error' => 'Incorrect Credentials']);
		}
		else{

			return view('admin.login', ['title' => 'Administrator Login']);
		}
	}

	public function loginSubmit(Request $request){

		$adminName = strtolower($request->input('adminName'));
		$password = md5($request->input('password'));

		$Administrator = Administrator:: where('username', $adminName)->where('password', $password)->first();

		if($Administrator){

			$request->session()->put('loginStatusAdmin', 'true');
			$request->session()->put('departmentUsername', $Administrator->username);
			$request->session()->put('departmentName', $Administrator->department);
			return Redirect::to('/admin/dashboard');
		}
		else{

			return Redirect::to('/admin?error=incorrect_credentials');
		}
	}

	public function logout(Request $request){

		$request->session()->flush();
		return Redirect::to('/admin');
	}
}
