<?php

namespace App\Http\Controllers\Admin;

use Redirect;
use Illuminate\Http\Request;

use App\Http\Controllers\Controller;
use App\Models\Administrator;

class AdminDashboardController extends Controller
{
	public function showDashboard(Request $request){

		try{

			$alert = $request->input('alert');

			return view('admin.dashboard',[

				'title' => 'Administrator Dashboard',
				'departmentName' => $request->session()->get('departmentName'),
				'departmentUsername' => $request->session()->get('departmentUsername'),
				'alert' => $alert
			]);
		}
		catch (\Exception $e) {

			return Redirect::to('/admin/dashboard?alert=error');
		}
	}
}
