@include('student.header')
<ol class="breadcrumb text-left">
	<li class="breadcrumb-item active">Computer Based Test (CBT)</li>
</ol>
<div class="row height-fit">
	<div class="col-xs-8 height-fit">
		<iframe src="{{$filePath}}" style="width: 100%;height: 400%;border: none;"></iframe>
	</div>
	<div class="col-xs-4 test-sidebar">
		<div class="row">
			<div class="col-xs-8">
				<br />
				<b>Name: </b>{{$name}}
				<br />
				<b>Registeration Number: </b>{{$registerationNumber}}
				<br />
				<b>Department: </b>{{$department}}
			</div>
			<div class="col-xs-4">
				<div class="pull-right">
					<img class="profile-picture" src="{{$profilePictureLink}}" />
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-xs-12">
				<br />
				Time Left :
				<span id="countdown" class="timer blue-primary"></span>
			</div>
			<div class="col-xs-12">
				<br />
				<table class="table">
					<tr>
						<th>Question No.</th>
						<th class="text-center">A</th>
						<th class="text-center">B</th>
						<th class="text-center">C</th>
						<th class="text-center">D</th>
						<th class="text-center">Unmark</th>
					</tr>
					@for ($i = 1; $i <= $numberOfQuestions; $i++)
						<tr class="background-white">
							<td>
								{{$i}}
							</td>
							<td class="text-center">
								<input type = "radio" name="q{{$i}}" value="a" onclick="upadteTestAnswers('q{{$i}}','a')" required
								@if ($answers['q' . $i]['a'] == 1)
									checked
								@endif
								>
							</td>
							<td class="text-center">
								<input type = "radio" name="q{{$i}}" value="b" onclick="upadteTestAnswers('q{{$i}}','b')" required
								@if ($answers['q' . $i]['b'] == 1)
									checked
								@endif>
							</td>
							<td class="text-center">
								<input type = "radio" name="q{{$i}}" value="c" onclick="upadteTestAnswers('q{{$i}}','c')" required
								@if ($answers['q' . $i]['c'] == 1)
									checked
								@endif>
							</td>
							<td class="text-center">
								<input type = "radio" name="q{{$i}}" value="d" onclick="upadteTestAnswers('q{{$i}}','d')" required
								@if ($answers['q' . $i]['d'] == 1)
									checked
								@endif>
							</td>
							<td class="text-center">
			<a onclick="resetQuestionAnswer('q{{$i}}');upadteTestAnswers('q{{$i}}','NULL')"><input type="button" value="Unmark"></a>
							</td>
						</tr>
					@endfor
				</table>
				<br />
				<form name="finishLogout" method="POST" onsubmit="return confirmTestSubmit();" action="/student/testSubmit">
					{{ csrf_field() }}
					<button class="btn btn-md btn-primary btn-block btn-signin" type="submit">Submit Test</button>
				</form>
			</div>
		</div>
	</div>
</div>

<script type="text/javascript">
	var seconds = {{$timeDuration}}
</script>
<script type="text/javascript" src="/js/student/timer.js"></script>

@include('student.footer')
