@include('student.header')
<ol class="breadcrumb text-left">
	<li class="breadcrumb-item active">Test Finished</li>
</ol>
<div class="row main-container">
	<div class="col-xs-offset-4 col-xs-4 text-center">
		<div class="center-block">
			<h4 class="blue-primary">Test Finished</h4>
			<br />
			<br />
			<table class="table">
				<tr>
					<td width="50%">
						<b>Number of Questions Attempted</b>
					</td>
					<td width="50%">
						{{$numberOfQuestionsAttempted}}
					</td>
				</tr>
				<tr>
					<td width="50%">
						<b>Time Taken</b>
					</td>
					<td width="50%">
						{{$hoursTaken}}:{{$minutesTaken}}:{{$secondsTaken}}
					</td>
				</tr>
			</table>
		</div>
	</div>
</div>
@include('student.footer')
