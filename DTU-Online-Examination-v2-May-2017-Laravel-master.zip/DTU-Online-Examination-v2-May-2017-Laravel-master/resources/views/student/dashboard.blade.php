@include('student.header')
<ol class="breadcrumb text-left">
	<li class="breadcrumb-item active">Dashboard</li>
</ol>
<div class="row student-main-container">
	<div class="col-xs-6 col-xs-offset-3">
		<div class="center-block">
			<div class="padding-left-right-20">
				<div class="row">
					<div class="col-xs-8">
						<br />
						<b>Name: </b>{{$name}}
						<br />
						<b>Registeration No: </b>{{$registerationNumber}}
						<br />
						<b>Department: </b>{{$department}}
					</div>
					<div class="col-xs-4">
						<div class="pull-right">
							<img class="profile-picture" src="{{$profilePictureLink}}" />
						</div>
					</div>
				</div>
			</div>
			<hr />
			<ul>
				@foreach ($numberOfQuestions as $key => $value)
	<li>CBT for {{$key}} contains {{$value}} questions.Time duration of Test is 90 Minutes (one &amp; half hrs).Test will started as per the exam. schedule .</li>

				@endforeach
			
<li>The question paper has 60 Multiple Choice Questions(MCQ) with one correct answer . For each correct answer , there will be +4 marks and for incorrect answer -1 mark . No marks for unattempted questions. </li>
<li>Students will be allowed to use non-programmable calculator .</li>
<li>Do not press any key of the  keyboard during test . Use mouse to mark the answers.</li> 
<li>The Test is to be given in One Single Attempt. Once the Test is Started, it can't be Paused for any Breaks.</li>
				<li>In case of test time is over ,  the Test would automatically finised after saving the answers.</li>
<li>After submission , the screen will display number of questions attempted</li>
				<li>Use of Unfair means during the Test is strictly prohibited.</li>
				
				
			</ul>
			<br />
			<div class="row">
				<form class="col-xs-6 col-xs-offset-3" name="dashboardForm" method="POST" onsubmit="return confirmStartTest();" action="/student/startTest">
					{{ csrf_field() }}
					@if(sizeof($numberOfQuestions) > 1)

						<div class="form-group">
							<label for="selectPaper">Select Paper</label>
							<select class="form-control" name="department" id="selectPaper">
							@foreach ($numberOfQuestions as $key => $value)

								<option value="{{$key}}">{{$key}}</option>

							@endforeach
							</select>
						</div>
					@else

						@foreach ($numberOfQuestions as $key => $value)

							<input type="hidden" name="department" value="{{$key}}" />

						@endforeach

					@endif

					<button class="btn btn-md btn-primary btn-block btn-signin" type="submit">Start Test</button>

				</form>
			</div>
		</div>
	</div>
</div>

@if (isset($alert))

	<script type="text/javascript">

		@if ($alert == 'error')

			alert('Some Error has occurred');

		@endif

		window.location.href = '/student/dashboard';

	</script>

@endif

@include('student.footer')
