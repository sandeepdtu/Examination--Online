@include('student.header')
<ol class="breadcrumb text-left">
	<li class="breadcrumb-item active">Login : Computer Based Test</li>
</ol>
<div class="row main-container">
	<div class="col-xs-offset-4 col-xs-4 text-center">
		<div class="center-block">
			<h4 class="blue-primary">Login</h4>
			<br />
			<br />
			<form name="loginForm" method="POST" action="/student/loginSubmit">
				{{ csrf_field() }}
				<div class="row">Registration No.
		<input type="text" name="registerationNumber" class="form-control" placeholder="Registeration Number" required autofocus>
		<span align="center" style="color:grey;"><small><i>(candidates applied in cse & IT , use cse reg. no. to login)</i></small></span>		
					<br />Date of Birth
					<input type="text" class="form-control" name="dateOfBirth" placeholder="Date of Birth" required>
					<br />
					@if (isset($error))
						<div class="error">
							{{$error}}
						</div>
					@endif
					<br />
					<button class="btn btn-md btn-primary btn-block btn-signin" type="submit">Login</button>
				</div>
			</form>
		</div>
	</div>
</div>
@include('student.footer')
