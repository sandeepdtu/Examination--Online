<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width">
		<meta name="csrf-token" content="{{ csrf_token() }}">

		<!-- Lnks -->

		<link rel="stylesheet" type="text/css" href="/bower_components/bootstrap/dist/css/bootstrap.min.css">
		<link rel="stylesheet" type="text/css" href="/bower_components/font-awesome/css/font-awesome.min.css">
		<link rel="stylesheet" type="text/css" href="/css/common.css">
		<link rel="shortcut icon" href="/icons/favicon.ico" type="image/x-icon">

		<input type="hidden" id="refresh" value="no">

		<!-- Title -->

		<title>{{$title}}</title>
	</head>
	<body>
		<div class="header">
			DTU Examination
		</div>
		<div class="height-fit">
