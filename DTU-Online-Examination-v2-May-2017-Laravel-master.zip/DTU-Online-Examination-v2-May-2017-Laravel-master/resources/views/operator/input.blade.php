@include('operator.header')
<ol class="breadcrumb text-left">
	<li class="breadcrumb-item active">Student Examination Acknowledgement</li>
</ol>
<div class="row main-container">
	<div class="col-xs-offset-4 col-xs-4 text-center">
		<div class="center-block">
			<h4 class="blue-primary">Student Examination Acknowledgement</h4>
			<br />
			<br />
			<form name="loginForm" method="POST" action="/operator/submit">
				{{ csrf_field() }}
				<div class="row">
					<input type="text" name="registerationNumber" class="form-control" placeholder="Registeration Number" required autofocus>
					<br />
					<input type="text" class="form-control" name="department" placeholder="Depeartment" required>
					<br />
					@if (isset($error))
						<div class="error">
							{{$error}}
						</div>
					@endif
					<br />
					<button class="btn btn-md btn-primary btn-block btn-signin" type="submit">Submit</button>
				</div>
			</form>
		</div>
	</div>
</div>
@include('operator.footer')
