@include('operator.header')
<ol class="breadcrumb text-left">
	<li class="breadcrumb-item active">
		<a href="/operator">
			Student exmaination acknowledgement
		</a>
	</li>
</ol>
<div class="row">
	<div class="col-xs-12">
		<div class="pull-right">
			<a onclick="window.print();return false;">
				<button class="btn btn-md btn-primary">Print</button>
			</a>
			<br />
			<br />
		</div>
	</div>
	<div class="col-xs-12 background-white">
		<br />
		<div class="row">
			<div class="col-xs-2">
				<img class="dtu-logo" src="/img/dtuLogo.png" />
			</div>
			<div class="col-xs-8 text-center">
				<h3>Delhi Technological University</h3>
				Shahbad Daulatpur, Main Bawana Road, Delhi, 110042
				<br />
				<br />
				<h5>Examination Answers Acknowledgement</h5>
			</div>
			<div class="col-xs-2">
				<div class="pull-right padding-top-20">
					No.{{$registerationNumber}}
				</div>
			</div>
			<div class="col-xs-12">
				<hr />
				<h4>Student Details</h4>
				<hr />
			</div>
			<div class="col-xs-6">
				<b>Name : </b>{{$name}}
				<br />
				<b>Registration Number : </b>{{$registerationNumber}}
				<br />
				<b>Department : </b>{{$department}}
				<br />
				<b>Physical Disablity : </b>{{$pd}}
			</div>
			<div class="col-xs-6">
				<div class="pull-right">
					<img class="profile-picture" src="{{$profilePictureLink}}" />
				</div>
			</div>
			<div class="col-xs-12">
				<h4>Test Details</h4>
				<hr />
				<b>Time Taken : </b>{{$hoursTaken}}:{{$minutesTaken}}:{{$secondsTaken}}
				<br />
				<br />
				<b>Answers : </b>
				<br />
				<br />
				<table class="table table-hover">
					<tr>
						<th width="50%" class="text-center">
							Question Number
						</th>
						<th width="50%" class="text-center">
							Marked Answer
						</th>
					</tr>
					@foreach ($questions as $questionNumber => $value)
						<tr>
							<td class="text-center">
								{{$questionNumber}}
							</td>
							<td class="text-center">
								{{$value}}
							</td>
						</tr>
					@endforeach
				</table>
				<br />
				<br />
			</div>
			<div class="col-xs-12">
				Signature of Student
				<br />
				<br />
			</div>
		</div>
	</div>
</div>
<br />
<br />
@include('operator.footer')
