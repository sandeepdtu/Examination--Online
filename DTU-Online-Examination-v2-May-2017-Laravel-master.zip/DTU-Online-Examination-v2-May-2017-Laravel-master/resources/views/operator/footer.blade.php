
		</div>

		<script type="text/javascript" src="/bower_components/jquery/dist/jquery.min.js"></script>
		<script type="text/javascript" src="/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

	</body>
</html>
