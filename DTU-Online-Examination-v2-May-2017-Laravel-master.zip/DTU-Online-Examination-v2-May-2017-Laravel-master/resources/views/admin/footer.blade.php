
		<script type="text/javascript" src="/bower_components/jquery/dist/jquery.min.js"></script>
		<script type="text/javascript" src="/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
		<script type="text/javascript" src="/bower_components/moment/min/moment.min.js"></script>
		<script type="text/javascript" src="/js/daterangepicker.min.js"></script>
		<script type="text/javascript" src="/js/admin/main.js"></script>

	</body>
</html>
