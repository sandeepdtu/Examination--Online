@include('admin.header')
<ol class="breadcrumb">
	<li class="breadcrumb-item">
		<a href="/admin/dashboard">Dashboard</a>
	</li>
	<li class="breadcrumb-item active">View Test</li>
</ol>
<div class="row">
	<div class="col-xs-12">
		<b>Number of Question : </b>{{$numberOfQuestions}}
		<br>
		<br>
		<b>Test Duration : </b>{{$values['timeHours']}} Hours {{$values['timeMinutes']}} Minutes
		<br />
		<br>
		<b>Marking Scheme : </b>
		<br>
		<br>
		<table>
			<tr>
				<td>Marks Gained Per Correct Answer (+)&nbsp;</td>
				<td>
					{{$values['marksGained']}}
				</td>
			</tr>
			<tr>
				<td>Marks Lost Per Incorrect Answer <span class="pull-right">(-)&nbsp;&nbsp;</span></td>
				<td>
					{{$values['marksLost']}}
				</td>
			</tr>
		</table>
		<br />
		<b>Timings : </b>{{$values['createEditTestDateRange']}}
		<br>
		<br>
		<b>Master Key : </b>
		<br>
		<br>
		<table class="table table-hover table-bordered">
			<tr class="background-white">
				<th width="50%">Question No.  </th>
				<th class="text-center">Anwer</th>
			</tr>
			@for ($i = 1; $i <= $numberOfQuestions; $i++)
				<tr class="background-white">
					<td width="50%">
						{{$i}}
					</td>
					<td class="text-center">
						@if ($values['q' . $i]['a'] == 1)
							A
						@elseif ($values['q' . $i]['b'] == 1)
							B
						@elseif ($values['q' . $i]['c'] == 1)
							C
						@elseif ($values['q' . $i]['d'] == 1)
							D
						@endif
					</td>
				</tr>
			@endfor
		</table>
		<br />
		<br />
	</div>
</div>
@include('admin.footer')
