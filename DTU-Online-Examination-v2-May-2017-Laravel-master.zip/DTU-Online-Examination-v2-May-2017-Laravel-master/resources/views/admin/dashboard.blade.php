@include('admin.header')
<div class="row text-center">
	<ol class="breadcrumb text-left">
		<li class="breadcrumb-item active">Dashboard</li>
	</ol>
	<h3 class="blue-primary padding-top-20">{{$departmentName}} ({{$departmentUsername}})</h3>
	<div class="padding-20"></div>
	<div class="row padding-top-20">
		<div class="col-xs-6 col-sm-3 col-md-2 no-padding div-for-circle" align="center">
			<a href="/admin/uploadNewTest">
				<div class="circle" align="center">
					<i class="fa fa-upload icon" aria-hidden="true"></i>
					<div class="text">
						Upload New Test
					</div>
				</div>
			</a>
		</div>
		<div class="col-xs-6 col-sm-3 col-md-2 no-padding div-for-circle" align="center">
			<a href="/admin/createNewTest">
				<div class="circle" align="center">
					<i class="fa fa-plus icon" aria-hidden="true"></i>
					<div class="text">
						Create New Test
					</div>
				</div>
			</a>
		</div>
		<div class="col-xs-6 col-sm-3 col-md-2 no-padding div-for-circle" align="center">
			<a href="/admin/editTest">
				<div class="circle" align="center">
					<i class="fa fa-pencil-square-o icon" aria-hidden="true"></i>
					<div class="text">
						Edit Test
					</div>
				</div>
			</a>
		</div>
		<div class="col-xs-6 col-sm-3 col-md-2 no-padding div-for-circle" align="center">
			<a href="/admin/viewTest">
				<div class="circle" align="center">
					<i class="fa fa-eye icon" aria-hidden="true"></i>
					<div class="text">
						View Test
					</div>
				</div>
			</a>
		</div>
		<div class="col-xs-6 col-sm-3 col-md-2 no-padding div-for-circle" align="center">
			<a href="/admin/results">
				<div class="circle" align="center">
					<i class="fa fa-calculator icon" aria-hidden="true"></i>
					<div class="text">
						View Results
					</div>
				</div>
			</a>
		</div>
		<div class="col-xs-6 col-sm-3 col-md-2 no-padding div-for-circle" align="center">
			<a href="/admin/allResults">
				<div class="circle" align="center">
					<i class="fa fa-calculator icon" aria-hidden="true"></i>
					<div class="text">
						View All Results
					</div>
				</div>
			</a>
		</div>
		<div class="col-xs-6 col-sm-3 col-md-2 no-padding div-for-circle" align="center">
			<a href="/admin/resetStudentLogin">
				<div class="circle" align="center">
					<i class="fa fa-refresh icon" aria-hidden="true"></i>
					<div class="text">
						Reset Student <br /> Login
					</div>
				</div>
			</a>
		</div>
		<div class="col-xs-6 col-sm-3 col-md-2 no-padding div-for-circle" align="center">
			<a href="/admin/logout">
				<div class="circle" align="center">
					<i class="fa fa-sign-out icon" aria-hidden="true"></i>
					<div class="text">
						Logout
					</div>
				</div>
			</a>
		</div>
	</div>
</div>

@if (isset($alert))

	<script type="text/javascript">

		@if ($alert == 'error')

			alert('Some Error has occurred');

		@endif

		@if ($alert == 'fileUploaded')

			alert('Test file successfully uploaded');

		@endif

		@if ($alert == 'testDetails')

			alert('Test Deatils successfully saved');

		@endif

		@if ($alert == 'resetStudentLogin')

			alert('Student login reset successful.');

		@endif

		window.location.href = '/admin/dashboard';

	</script>

@endif

@include('admin.footer')
