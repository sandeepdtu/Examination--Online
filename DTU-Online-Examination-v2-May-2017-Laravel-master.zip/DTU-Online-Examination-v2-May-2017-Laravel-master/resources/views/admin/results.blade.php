@include('admin.header')
<ol class="breadcrumb">
	<li class="breadcrumb-item">
		<a href="/admin/dashboard">Dashboard</a>
	</li>
	<li class="breadcrumb-item active">Results</li>
</ol>
<div class="row">
	<div class="col-xs-12">
		<div class="pull-right">
			<a onclick="window.print();return false;">
				<button class="btn btn-md btn-primary">Print</button>
			</a>
			<a href="{{$file}}" download>
				<button class="btn btn-md btn-primary">Download</button>
			</a>
		</div>
	</div>
	<div class="col-xs-12">
		<br />
	</div>
	<div class="col-xs-12">
		<table class="table table-hover table-bordered background-white">
			<tr>
				@if($type == 0)
					<th width="20%" class="text-center">Registration No.</th>
					<th width="20%" class="text-center">Name</th>
					<th width="15%" class="text-center">Number of Attempted Questions</th>
					<th width="15%" class="text-center">Number of Correct Questions</th>
					<th width="15%" class="text-center">Number of Incorrect Questions</th>
					<th width="15%" class="text-center">Marks</th>
				@endif
				@if($type == 1)
					<th width="20%" class="text-center">Registration No.</th>
					<th width="20%" class="text-center">Name</th>
					<th width="10%" class="text-center">Number of Attempted Questions</th>
					<th width="10%" class="text-center">Number of Correct Questions</th>
					<th width="10%" class="text-center">Number of Incorrect Questions</th>
					<th width="10%" class="text-center">Marks</th>
					<th width="10%" class="text-center">Department</th>
				@endif
			</tr>
			@foreach($results as $department => $departmentResults)
				@foreach($departmentResults as $departmentResult)
					<tr>
						<td class="text-center">{{$departmentResult['registerationNumber']}}</td>
						<td class="text-center">{{$departmentResult['name']}}</td>
						<td class="text-center">{{$departmentResult['attempted']}}</td>
						<td class="text-center">{{$departmentResult['correct']}}</td>
						<td class="text-center">{{$departmentResult['incorrect']}}</td>
						<td class="text-center">{{$departmentResult['marks']}}</td>
						@if($type == 1)
							<td class="text-center">{{$department}}</td>
						@endif
					</tr>
				@endforeach
			@endforeach
		</table>
	</div>
</div>
@include('admin.footer')
