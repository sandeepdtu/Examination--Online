@include('admin.header')
<ol class="breadcrumb">
	<li class="breadcrumb-item">
		<a href="/admin/dashboard">Dashboard</a>
	</li>
	@if ($type == 'create')
		<li class="breadcrumb-item active">Create New Test</li>
	@endif
	@if ($type == 'edit')
		<li class="breadcrumb-item active">Edit Test</li>
	@endif
</ol>
<div class="row">
	<div class="col-xs-12">
		<form name="createEditTestForm" method = "POST" onsubmit="return confirmCreateEditNewTest();" action="/admin/createEditTest">
			{{ csrf_field() }}
			<input type="hidden" name="numberOfQuestions" value="{{$numberOfQuestions}}" />
			<b>Number of Question : {{$numberOfQuestions}}</b>
			<br>
			<br>
			<b>Test Duration : </b>
			<br />
			<br />
			<div class="form-inline">
				<div class="form-group">
					<input type="number" id="timeHours" name="timeHours" class="form-control" min="0" value="{{$values['timeHours']}}" max="99" required>
					<label for="timeHours">Hours</label>
				</div>
				<div class="form-group">
					<input type="number" id="timeMinutes" name="timeMinutes" class="form-control" min="0" value="{{$values['timeMinutes']}}" max="59" required>
					<label for="timeMinutes">Minutes</label>
				</div>
			</div>
			<br>
			<b>Marking Scheme : </b>
			<br>
			<br>
			<table>
				<tr>
					<td>Marks Gained Per Correct Answer (+)&nbsp;</td>
					<td>
						<input type="number" name="mgpca" min="0" value="{{$values['marksGained']}}" class="form-control" required>
					</td>
				</tr>
				<tr>
					<td>Marks Lost Per Incorrect Answer <span class="pull-right">(-)&nbsp;&nbsp;</span></td>
					<td>
						<input type="number" name="mlpia" min="0" value="{{$values['marksLost']}}" class="form-control" required>
					</td>
				</tr>
			</table>
			<br />
			<b>Timings : </b>
			<br>
			<br />
			<div class="col-xs-6 no-padding">
				<input type="text" name="createEditTestDateRange" id="createEditTestDateRange" value="{{$values['createEditTestDateRange']}}" class="form-control" required />
			</div>
			<br />
			<br />
			<br>
			<b>Master Key : </b>
			<br>
			<br>
			<table class="table table-hover table-bordered">
				<tr class="background-white">
					<th width="40%">Question No. \ Anwers </th>
					<th class="text-center">A</th>
					<th class="text-center">B</th>
					<th class="text-center">C</th>
					<th class="text-center">D</th>
				</tr>
				@for ($i = 1; $i <= $numberOfQuestions; $i++)
					<tr class="background-white">
						<td width="40%">
							{{$i}}
						</td>
						<td class="text-center">
							<input type = "radio" name="q{{$i}}" value="a" 
							@if ($values['q' . $i]['a'] == 1)
								checked
							@endif
							>
						</td>
						<td class="text-center">
							<input type = "radio" name="q{{$i}}" value="b"
							@if ($values['q' . $i]['b'] == 1)
								checked
							@endif>
						</td>
						<td class="text-center">
							<input type = "radio" name="q{{$i}}" value="c" 
							@if ($values['q' . $i]['c'] == 1)
								checked
							@endif>
						</td>
						<td class="text-center">
							<input type = "radio" name="q{{$i}}" value="d"
							@if ($values['q' . $i]['d'] == 1)
								checked
							@endif>
						</td>
					</tr>
				@endfor
			</table>
			<br />
			<div class="row">
				@if ($type == 'create')
					<div class="col-xs-2 col-xs-offset-4">
						<button class="btn btn-md btn-primary btn-block btn-signin" type="reset">Reset</button>
					</div>
				@endif
				@if ($type == 'edit')
					<div class="col-xs-2 col-xs-offset-4">
						<a href="/admin/dashboard">
							<button class="btn btn-md btn-warning btn-block btn-signin" type="button">Cancel</button>
						</a>
					</div>
				@endif
				@if ($type == 'create')
					<div class="col-xs-2">
						<button class="btn btn-md btn-success btn-block btn-signin" type="submit">Create Test</button>
					</div>
				@endif
				@if ($type == 'edit')
					<div class="col-xs-2">
						<button class="btn btn-md btn-success btn-block btn-signin" type="submit">Save Test</button>
					</div>
				@endif
			</div>
			<br />
			<br />
			<br />
		</form>
	</div>
</div>
@include('admin.footer')
