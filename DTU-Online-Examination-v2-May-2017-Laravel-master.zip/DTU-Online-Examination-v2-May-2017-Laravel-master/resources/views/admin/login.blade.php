@include('admin.header')
<ol class="breadcrumb text-left">
	<li class="breadcrumb-item active">Login</li>
</ol>
<div class="row main-container">
	<div class="col-xs-offset-4 col-xs-4 text-center">
		<div class="center-block">
			<h4 class="blue-primary">Login</h4>
			<br />
			<br />
			<form name="loginForm" method="POST" action="/admin/loginSubmit">
				{{ csrf_field() }}
				<div class="row">
					<input type="text" name="adminName" class="form-control" placeholder="Admin Name" required autofocus>
					<br />
					<input type="password" class="form-control" name="password" placeholder="Password" required>
					<br />
					@if (isset($error))
						<div class="error">
							{{$error}}
						</div>
					@endif
					<br />
					<button class="btn btn-md btn-primary btn-block btn-signin" type="submit">Login</button>
				</div>
			</form>
		</div>
	</div>
</div>
@include('admin.footer')
