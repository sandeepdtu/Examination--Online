@include('admin.header')
<ol class="breadcrumb text-left">
	<li class="breadcrumb-item">
		<a href="/admin/dashboard">Dashboard</a>
	</li>
	<li class="breadcrumb-item active">Reset Student Login</li>
</ol>
<div class="row main-container">
	<div class="col-xs-offset-4 col-xs-4 text-center">
		<div class="center-block">
			<h4 class="blue-primary">Reset Login</h4>
			<br />
			<br />
			<form name="loginForm" method="POST" action="/admin/resetStudentLoginSubmit">
				{{ csrf_field() }}
				<div class="row">
					<input type="text" name="registerationNumber" class="form-control" placeholder="Registeration Number" required autofocus>
					<br />
					<br />
					<button class="btn btn-md btn-primary btn-block btn-signin" type="submit">Submit</button>
				</div>
			</form>
		</div>
	</div>
</div>
@include('admin.footer')
