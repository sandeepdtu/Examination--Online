@include('admin.header')
<ol class="breadcrumb">
	<li class="breadcrumb-item">
		<a href="/admin/dashboard">Dashboard</a>
	</li>
	<li class="breadcrumb-item active">Upload New Test</li>
</ol>
<div class="row main-container">
	<div class="col-xs-offset-4 col-xs-4 text-center">
		<div class="center-block">
			<h4 class="blue-primary">Upload New Test</h4>
			<br />
			<br />
			{!! Form::open(array('action' => 'Admin\AdminTestController@uploadNewTestSubmit', 'onsubmit' => 'return confirmUploadNewTest();', 'enctype' => 'multipart/form-data')) !!}
				{{ csrf_field() }}
				<div class="row text-left">
					<input type="number" class="form-control" name="numberOfQuestions" placeholder="Number of Questions" min="1" max="{{$maxQuestionsCount}}" required>
					<br />
					{!! Form::file('file') !!}
					<br />
					Note: Choose a PDF file.
					<br />
					<br />
					@if (isset($error))
						<div class="error text-center">
							{{$error}}
						</div>
					@endif
					<br />
					<button class="btn btn-md btn-primary btn-block btn-signin" type="submit">Upload Test</button>
				</div>
			{!! Form::close() !!}
		</div>
	</div>
</div>
@include('admin.footer')
