<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Admin

Route::get('/admin/', [

	'middleware' => 'admin.loginCheck.true',
	'uses' => 'Admin\AdminLoginController@showLogin'
]);

Route::post('/admin/loginSubmit', [

	'uses' => 'Admin\AdminLoginController@loginSubmit'
]);

Route::get('/admin/dashboard', [

	'middleware' => 'admin.loginCheck.false',
	'uses' => 'Admin\AdminDashboardController@showDashboard'
]);

Route::get('/admin/uploadNewTest', [

	'middleware' => 'admin.loginCheck.false',
	'uses' => 'Admin\AdminTestController@showUploadNewTest'
]);

Route::post('/admin/uploadNewTest', [

	'middleware' => 'admin.loginCheck.false',
	'uses' => 'Admin\AdminTestController@uploadNewTestSubmit'
]);

Route::get('/admin/createNewTest', [

	'middleware' => 'admin.loginCheck.false',
	'uses' => 'Admin\AdminTestController@showCreateNewTest'
]);

Route::post('/admin/createEditTest', [

	'middleware' => 'admin.loginCheck.false',
	'uses' => 'Admin\AdminTestController@createEditTestSubmit'
]);

Route::get('/admin/editTest', [

	'middleware' => 'admin.loginCheck.false',
	'uses' => 'Admin\AdminTestController@showEditTest'
]);

Route::get('/admin/viewTest', [

	'middleware' => 'admin.loginCheck.false',
	'uses' => 'Admin\AdminTestController@showViewTest'
]);

Route::get('/admin/results', [

	'middleware' => 'admin.loginCheck.false',
	'uses' => 'Admin\AdminResultController@showResults'
]);

Route::get('/admin/allResults', [

	'middleware' => 'admin.loginCheck.false',
	'uses' => 'Admin\AdminResultController@showAllResults'
]);

Route::get('/admin/resetStudentLogin', [

	'middleware' => 'admin.loginCheck.false',
	'uses' => 'Admin\AdminResetController@showResetStudentLogin'
]);

Route::post('/admin/resetStudentLoginSubmit', [

	'middleware' => 'admin.loginCheck.false',
	'uses' => 'Admin\AdminResetController@resetStudentLoginSubmit'
]);

Route::get('/admin/logout', [

	'uses' => 'Admin\AdminLoginController@logout'
]);

// Student

Route::get('/', [

	'uses' => 'Student\StudentLoginController@redirectLogin'
]);

Route::get('/student/', [

	'middleware' => 'student.loginCheck.true',
	'uses' => 'Student\StudentLoginController@showLogin'
]);

Route::post('/student/loginSubmit', [

	'uses' => 'Student\StudentLoginController@loginSubmit'
]);

Route::get('/student/dashboard', [

	'middleware' => ['student.loginCheck.false','student.testStartedCheck.true'],
	'uses' => 'Student\StudentDashboardController@showDashboard'
]);

Route::post('/student/startTest', [

	'middleware' => 'student.loginCheck.false',
	'uses' => 'Student\StudentTestController@startTest'
]);

Route::get('/student/test', [

	'middleware' => ['student.loginCheck.false','student.testStartedCheck.false'],
	'uses' => 'Student\StudentTestController@showTest'
]);

Route::patch('/student/patchTestAnswer', [

	'middleware' => ['student.loginCheck.false','student.testStartedCheck.false'],
	'uses' => 'Student\StudentTestController@patchTestAnswer'
]);

Route::post('/student/testSubmit', [

	'middleware' => ['student.loginCheck.false','student.testStartedCheck.false'],
	'uses' => 'Student\StudentTestController@testSubmit'
]);

Route::get('/student/testFinished', [

	'middleware' => ['student.loginCheck.true','student.testStartedCheck.true'],
	'uses' => 'Student\StudentTestController@showTestFinished'
]);

Route::get('/operator', [

	'uses' => 'Operator\OperatorController@showInput'
]);

Route::post('/operator/submit', [

	'uses' => 'Operator\OperatorController@postSubmit'
]);

Route::get('/operator/acknowledgement/{registerationNumber}/{department}', [

	'uses' => 'Operator\OperatorController@showAcknowledgement'
]);
